package com.gullyscore.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PitchGreen = Color(0xFF1B7F3B)
val LeatherRed = Color(0xFFB3261E)
val Cream = Color(0xFFFFFBF2)

private val Colors = lightColorScheme(
    primary = PitchGreen,
    secondary = LeatherRed,
    background = Cream,
    surface = Color.White,
)

@Composable
fun GullyScoreTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
