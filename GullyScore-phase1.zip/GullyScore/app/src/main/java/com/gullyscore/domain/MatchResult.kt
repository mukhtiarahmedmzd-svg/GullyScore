package com.gullyscore.domain

data class ChaseInfo(val target: Int, val runsNeeded: Int, val ballsRemaining: Int) {
    val requiredRate get() = if (ballsRemaining <= 0) 0.0 else runsNeeded * 6.0 / ballsRemaining
}

object MatchResult {

    /** Target for the second innings = first innings runs + 1. */
    fun chase(config: MatchConfig, first: InningsState, second: InningsState): ChaseInfo {
        val target = first.runs + 1
        return ChaseInfo(
            target = target,
            runsNeeded = maxOf(0, target - second.runs),
            ballsRemaining = maxOf(0, config.maxBalls - second.legalBalls),
        )
    }

    /** Returns the result text, or null while the match is still in progress. */
    fun result(
        config: MatchConfig, firstTeam: String, secondTeam: String,
        first: InningsState, second: InningsState,
    ): String? {
        val target = first.runs + 1
        if (second.runs >= target) {
            val wktsLeft = config.maxWickets - second.wickets
            return "$secondTeam won by $wktsLeft wicket${if (wktsLeft == 1) "" else "s"}"
        }
        if (!second.isComplete) return null
        val margin = first.runs - second.runs
        return if (margin == 0) "Match tied"
        else "$firstTeam won by $margin run${if (margin == 1) "" else "s"}"
    }
}
