package com.gullyscore.domain

data class Extras(val wides: Int = 0, val noBalls: Int = 0, val byes: Int = 0, val legByes: Int = 0) {
    val total get() = wides + noBalls + byes + legByes
}

data class BatterStats(
    val playerId: String, val runs: Int, val balls: Int, val fours: Int, val sixes: Int,
    val isOut: Boolean, val howOut: WicketKind?, val outBowlerId: String?, val fielderName: String?,
) {
    val strikeRate get() = if (balls == 0) 0.0 else runs * 100.0 / balls
}

data class BowlerStats(
    val playerId: String, val legalBalls: Int, val runs: Int, val wickets: Int,
    val maidens: Int, val wides: Int, val noBalls: Int,
) {
    val oversText get() = "${legalBalls / 6}.${legalBalls % 6}"
    val economy get() = if (legalBalls == 0) 0.0 else runs * 6.0 / legalBalls
}

data class InningsState(
    val runs: Int, val wickets: Int, val legalBalls: Int, val extras: Extras,
    val batters: List<BatterStats>, val bowlers: List<BowlerStats>,
    /** Crease after the last ball (strike already rotated). After a wicket the
     *  dismissed batter's id stays in its slot until the app puts a new batter in. */
    val strikerId: String?, val nonStrikerId: String?,
    val overJustCompleted: Boolean, val thisOver: List<Delivery>,
    val isAllOut: Boolean, val isComplete: Boolean,
) {
    val oversText get() = "${legalBalls / 6}.${legalBalls % 6}"
    val runRate get() = if (legalBalls == 0) 0.0 else runs * 6.0 / legalBalls
}

private class BatB(val id: String) {
    var runs = 0; var balls = 0; var fours = 0; var sixes = 0
    var out = false; var how: WicketKind? = null; var by: String? = null; var fielder: String? = null
}

private class BowlB(val id: String) {
    var balls = 0; var runs = 0; var wkts = 0; var maidens = 0; var wides = 0; var nb = 0
}

object InningsScorer {

    fun score(config: MatchConfig, deliveries: List<Delivery>): InningsState {
        var runs = 0; var wickets = 0; var legal = 0
        var wides = 0; var noBalls = 0; var byes = 0; var legByes = 0
        val batters = LinkedHashMap<String, BatB>()
        val bowlers = LinkedHashMap<String, BowlB>()
        val overLedger = HashMap<Pair<Int, String>, IntArray>() // [runsConceded, legalBalls]
        var striker: String? = null
        var nonStriker: String? = null
        var thisOver = mutableListOf<Delivery>()
        var overJustCompleted = false

        for (d in deliveries) {
            val penalty = when (d.type) {
                DeliveryType.WIDE -> config.wideRuns
                DeliveryType.NO_BALL -> config.noBallRuns
                else -> 0
            }
            val total = penalty + d.runs
            val legalBall = d.type.isLegalBall

            val bat = batters.getOrPut(d.strikerId) { BatB(d.strikerId) }
            batters.getOrPut(d.nonStrikerId) { BatB(d.nonStrikerId) }
            val bowl = bowlers.getOrPut(d.bowlerId) { BowlB(d.bowlerId) }

            runs += total
            when (d.type) {
                DeliveryType.WIDE -> { wides += total; bowl.wides += total }
                DeliveryType.NO_BALL -> { noBalls += penalty; bowl.nb += penalty }
                DeliveryType.BYE -> byes += d.runs
                DeliveryType.LEG_BYE -> legByes += d.runs
                DeliveryType.LEGAL -> {}
            }

            val batRuns = if (d.type == DeliveryType.LEGAL || d.type == DeliveryType.NO_BALL) d.runs else 0
            if (d.type != DeliveryType.WIDE) bat.balls++
            bat.runs += batRuns
            if (batRuns == 4) bat.fours++
            if (batRuns == 6) bat.sixes++

            val conceded = when (d.type) {
                DeliveryType.LEGAL -> d.runs
                DeliveryType.WIDE, DeliveryType.NO_BALL -> total
                else -> 0
            }
            bowl.runs += conceded

            val overIndex = legal / 6
            val ledger = overLedger.getOrPut(overIndex to d.bowlerId) { IntArray(2) }
            ledger[0] += conceded
            if (legalBall) { ledger[1]++; legal++; bowl.balls++ }

            if (d.wicket != null) {
                wickets++
                val outId = d.dismissedId ?: d.strikerId
                val ob = batters.getOrPut(outId) { BatB(outId) }
                ob.out = true; ob.how = d.wicket; ob.fielder = d.fielderName
                ob.by = if (d.wicket.bowlerCredited) d.bowlerId else null
                if (d.wicket.bowlerCredited) bowl.wkts++
            }

            // Strike rotation: odd runs swap ends, then end of over swaps again.
            var s = d.strikerId
            var n = d.nonStrikerId
            if (d.runs % 2 == 1) { val t = s; s = n; n = t }
            overJustCompleted = legalBall && legal % 6 == 0
            if (overJustCompleted) { val t = s; s = n; n = t }
            striker = s; nonStriker = n

            if (overJustCompleted) thisOver = mutableListOf() else thisOver.add(d)
        }

        for ((key, arr) in overLedger) {
            if (arr[1] == 6 && arr[0] == 0) bowlers.getValue(key.second).maidens++
        }

        val allOut = wickets >= config.maxWickets
        return InningsState(
            runs = runs, wickets = wickets, legalBalls = legal,
            extras = Extras(wides, noBalls, byes, legByes),
            batters = batters.values.map {
                BatterStats(it.id, it.runs, it.balls, it.fours, it.sixes, it.out, it.how, it.by, it.fielder)
            },
            bowlers = bowlers.values.map {
                BowlerStats(it.id, it.balls, it.runs, it.wkts, it.maidens, it.wides, it.nb)
            },
            strikerId = striker, nonStrikerId = nonStriker,
            overJustCompleted = overJustCompleted, thisOver = thisOver,
            isAllOut = allOut, isComplete = allOut || legal >= config.maxBalls,
        )
    }
}
