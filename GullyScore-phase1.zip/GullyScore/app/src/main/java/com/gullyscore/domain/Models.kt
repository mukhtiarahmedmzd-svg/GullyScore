package com.gullyscore.domain

enum class DeliveryType(val isLegalBall: Boolean) {
    LEGAL(true), WIDE(false), NO_BALL(false), BYE(true), LEG_BYE(true)
}

enum class WicketKind(val bowlerCredited: Boolean) {
    BOWLED(true), CAUGHT(true), LBW(true), STUMPED(true), HIT_WICKET(true), RUN_OUT(false)
}

data class Player(val id: String, val name: String)

/** Match rules. Gully cricket varies, so everything here is adjustable. */
data class MatchConfig(
    val oversPerInnings: Int,
    val playersPerSide: Int = 11,
    val wideRuns: Int = 1,
    val noBallRuns: Int = 1,
    val lastManStands: Boolean = false,
) {
    val maxBalls get() = oversPerInnings * 6
    val maxWickets get() = if (lastManStands) playersPerSide else playersPerSide - 1
}

/**
 * One ball bowled. The whole innings is a list of these (an event log).
 * Score, stats and undo are all derived from the list: Undo = remove the last one.
 *
 * runs meaning by type:
 *  LEGAL   -> runs off the bat
 *  WIDE    -> extra runs run besides the wide penalty
 *  NO_BALL -> runs off the bat besides the no-ball penalty
 *  BYE / LEG_BYE -> byes / leg-byes run
 */
data class Delivery(
    val seq: Int,
    val strikerId: String,
    val nonStrikerId: String,
    val bowlerId: String,
    val type: DeliveryType = DeliveryType.LEGAL,
    val runs: Int = 0,
    val wicket: WicketKind? = null,
    val dismissedId: String? = null,
    val fielderName: String? = null,
)
