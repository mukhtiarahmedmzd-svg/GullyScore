package com.gullyscore.domain

import org.junit.Assert.*
import org.junit.Test

class InningsScorerTest {
    private val cfg = MatchConfig(oversPerInnings = 2, playersPerSide = 3)

    private var seq = 0
    private fun d(
        runs: Int = 0, type: DeliveryType = DeliveryType.LEGAL,
        striker: String = "A", non: String = "B", bowler: String = "X",
        wicket: WicketKind? = null, dismissed: String? = null,
    ) = Delivery(seq++, striker, non, bowler, type, runs, wicket, dismissed)

    private fun balls(n: Int, runs: Int = 0) = List(n) { d(runs) }

    @Test fun singleRotatesStrike() {
        val s = InningsScorer.score(cfg, listOf(d(1)))
        assertEquals(1, s.runs); assertEquals("B", s.strikerId); assertEquals("A", s.nonStrikerId)
    }

    @Test fun overEndSwapsStrike() {
        val s = InningsScorer.score(cfg, balls(6))
        assertTrue(s.overJustCompleted); assertEquals("B", s.strikerId)
        assertEquals("1.0", s.oversText); assertEquals(6, s.legalBalls)
    }

    @Test fun wideIsNotALegalBallAndNotFacedByBatter() {
        val s = InningsScorer.score(cfg, listOf(d(type = DeliveryType.WIDE)))
        assertEquals(1, s.runs); assertEquals(0, s.legalBalls); assertEquals(1, s.extras.wides)
        assertEquals(0, s.batters.first { it.playerId == "A" }.balls)
        assertEquals(1, s.bowlers.first().runs)
    }

    @Test fun noBallWithFourCreditsBatterAndBowler() {
        val s = InningsScorer.score(cfg, listOf(d(4, DeliveryType.NO_BALL)))
        assertEquals(5, s.runs); assertEquals(0, s.legalBalls)
        val a = s.batters.first { it.playerId == "A" }
        assertEquals(4, a.runs); assertEquals(1, a.fours); assertEquals(1, a.balls)
        assertEquals(5, s.bowlers.first().runs); assertEquals(1, s.extras.noBalls)
    }

    @Test fun byesAndLegByesAreNotBatterOrBowlerRuns() {
        val s = InningsScorer.score(cfg, listOf(d(2, DeliveryType.BYE), d(1, DeliveryType.LEG_BYE)))
        assertEquals(3, s.runs); assertEquals(2, s.legalBalls)
        assertEquals(0, s.batters.first { it.playerId == "A" }.runs)
        assertEquals(0, s.bowlers.first().runs)
        assertEquals(2, s.extras.byes); assertEquals(1, s.extras.legByes)
    }

    @Test fun maidenOver() {
        assertEquals(1, InningsScorer.score(cfg, balls(6)).bowlers.first().maidens)
    }

    @Test fun overWithWideIsNotMaiden() {
        val s = InningsScorer.score(cfg, listOf(d(type = DeliveryType.WIDE)) + balls(6))
        assertEquals(0, s.bowlers.first().maidens); assertEquals(6, s.legalBalls)
    }

    @Test fun bowlerWicketAndBatterOut() {
        val s = InningsScorer.score(cfg, listOf(d(wicket = WicketKind.BOWLED)))
        assertEquals(1, s.wickets); assertEquals(1, s.bowlers.first().wickets)
        assertTrue(s.batters.first { it.playerId == "A" }.isOut)
    }

    @Test fun runOutIsNotCreditedToBowler() {
        val s = InningsScorer.score(cfg, listOf(d(1, wicket = WicketKind.RUN_OUT, dismissed = "B")))
        assertEquals(1, s.wickets); assertEquals(0, s.bowlers.first().wickets)
        assertTrue(s.batters.first { it.playerId == "B" }.isOut)
        assertFalse(s.batters.first { it.playerId == "A" }.isOut)
    }

    @Test fun allOutEndsInnings() {
        val s = InningsScorer.score(cfg, listOf(
            d(wicket = WicketKind.BOWLED, striker = "A", non = "B"),
            d(wicket = WicketKind.BOWLED, striker = "C", non = "B"),
        ))
        assertTrue(s.isAllOut); assertTrue(s.isComplete)
    }

    @Test fun lastManStandsNeedsOneMoreWicket() {
        val s = InningsScorer.score(cfg.copy(lastManStands = true), listOf(
            d(wicket = WicketKind.BOWLED, striker = "A", non = "B"),
            d(wicket = WicketKind.BOWLED, striker = "C", non = "B"),
        ))
        assertFalse(s.isAllOut)
    }

    @Test fun oversFinishedCompletesInnings() {
        assertTrue(InningsScorer.score(cfg, balls(12)).isComplete)
        assertFalse(InningsScorer.score(cfg, balls(11)).isComplete)
    }

    @Test fun undoIsJustDroppingLastDelivery() {
        val all = listOf(d(4), d(6))
        assertEquals(10, InningsScorer.score(cfg, all).runs)
        assertEquals(4, InningsScorer.score(cfg, all.dropLast(1)).runs)
    }

    @Test fun targetAndChase() {
        val first = InningsScorer.score(cfg, balls(12, 1))   // 12 runs
        val second = InningsScorer.score(cfg, balls(3, 2))   // 6 runs, 3 balls
        val chase = MatchResult.chase(cfg, first, second)
        assertEquals(13, chase.target); assertEquals(7, chase.runsNeeded); assertEquals(9, chase.ballsRemaining)
    }

    @Test fun resultsWinTieLossAndInProgress() {
        val first = InningsScorer.score(cfg, balls(12, 1))   // 12
        val won = InningsScorer.score(cfg, balls(7, 2))      // 14, 2 wkts left
        assertEquals("Lions won by 2 wickets", MatchResult.result(cfg, "Tigers", "Lions", first, won))
        val tied = InningsScorer.score(cfg, balls(12, 1))
        assertEquals("Match tied", MatchResult.result(cfg, "Tigers", "Lions", first, tied))
        val lost = InningsScorer.score(cfg, balls(12, 0))
        assertEquals("Tigers won by 12 runs", MatchResult.result(cfg, "Tigers", "Lions", first, lost))
        assertNull(MatchResult.result(cfg, "Tigers", "Lions", first, InningsScorer.score(cfg, balls(3))))
    }
}
